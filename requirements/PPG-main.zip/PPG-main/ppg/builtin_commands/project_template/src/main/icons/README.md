<div>Iconos diseñados por <a href="https://www.flaticon.es/autores/samlakodad" title="samlakodad">samlakodad</a> from <a href="https://www.flaticon.es/" title="Flaticon">www.flaticon.es</a></div>

You can create Icon.ico from the .png files with
[an online tool](http://icoconvert.com/Multi_Image_to_one_icon/).
